<?php if (is_blog()): ?>
	<form action="/blog/search/" method="get" id="blog_search">
	<label for="blog_search_term">Search Blog:</label>
	<input id="blog_search_term" type="text" name="term" />
	<button class="button button-small box-round">Search</button>
	</form>
<?php endif; ?>
	
<!-- Blog -->
<?php if(is_blog() && $page['slug'] != 'search-results' && $page['slug'] != 'blog' && !$is_tag && !$is_category && !$is_paginated_index ): ?>
		<!-- ShareThis Widget -->
<!--
		<script>
			var switchTo5x=true;
		</script>
			<script src="https://ws.sharethis.com/button/buttons.js"></script>
		<script>
			stLight.options({publisher: "ur-54ed7f81-87ee-91f2-fc4a-b5e34bf9a248", doNotHash: true, doNotCopy: true, hashAddressBar: false});
		</script>
		<div class="share-article-links">
			<p class="share-text">Share Article:</p>
			<span class='st_googleplus_large' displayText='Share on Google+'></span>
			<span class='st_facebook_large' displayText='Share on Facebook'></span>
			<span class='st_twitter_large' displayText='Tweet This'></span>
			<span class='st_linkedin_large' displayText='Share on LinkedIn'></span>
			<span class='st_pinterest_large' displayText='Share on Pinterest'></span>
			<span class='st_fblike_large' displayText='Like This on Facebook'></span>
			<span class='st_plusone_large' displayText='Recommend This on Google'></span>
		</div>
-->
<?php endif; ?>