<div class="cycle-slideshow"
	data-cycle-timeout="8000"
	data-cycle-loader=true
    data-cycle-progressive="#images"
>
<img class="hpslide" src="/assets/images/slideshow/slide1.jpg" alt="" width="2000" height="1125" decoding="async"  />
		
<script id="images" type="text/cycle">
[
"<img class='hpslide' src='assets/images/slideshow/slide2.jpg' alt='' width='2000' height='1125' decoding='async' />",
"<img class='hpslide' src='assets/images/slideshow/slide3.jpg' alt='' width='2000' height='1125' decoding='async' />",
"<img class='hpslide' src='assets/images/slideshow/slide4.jpg' alt='' width='2000' height='1125' decoding='async' />",
"<img class='hpslide' src='assets/images/slideshow/slide4.jpg' alt='' width='2000' height='1125' decoding='async' />"
]
</script>
</div>