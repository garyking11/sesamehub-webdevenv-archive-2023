<div class="socialmedia">
	<!-- 
		<a class="asset" aria-label="asset" href="#">
			<span class="icon fa-brands fa-fw fa-asset" aria-hidden="true" role="img"></span>
		</a> 
	-->
	<a class="facebook" aria-label="facebook" href="#">
		<span class="icon fa-brands fa-fw fa-facebook-f" aria-hidden="true" role="img"></span>
	</a><a class="google" aria-label="google" href="#">
		<span class="icon fa-brands fa-fw fa-google" aria-hidden="true" role="img"></span>
	</a><a class="youtube" aria-label="youtube" href="#">
		<span class="icon fa-brands fa-fw fa-youtube" aria-hidden="true" role="img"></span>
	</a><a class="twitter" aria-label="twitter" href="#">
		<span class="icon fa-brands fa-fw fa-twitter" aria-hidden="true" role="img"></span>
	</a><a class="blog" aria-label="blog" href="/blog">
		<span class="icon fa-solid fa-fw fa-rss" aria-hidden="true" role="img"></span>
	</a><a class="healthgrades" aria-label="healthgrades" href="#">
		<span class="icon fa-fw fa-healthgrades2" aria-hidden="true" role="img"></span>
	</a><a class="instagram" aria-label="instagram" href="#">
		<span class="icon fa-brands fa-fw fa-instagram" aria-hidden="true" role="img"></span>
	</a>
</div><!--/social-media-->